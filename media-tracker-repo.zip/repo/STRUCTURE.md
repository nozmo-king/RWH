# Repository Structure

```
media-tracker/
├── .github/                        # GitHub-specific files
│   ├── ISSUE_TEMPLATE/
│   │   ├── bug_report.md          # Bug report template
│   │   └── feature_request.md     # Feature request template
│   └── pull_request_template.md   # PR template
│
├── docs/                           # Documentation
│   ├── README.md                  # User guide (detailed)
│   ├── QUICKSTART.md              # 3-step quick start
│   ├── STYLE_GUIDE.md             # HTML theme comparison
│   ├── ARCH_SETUP.md              # Arch Linux specific guide
│   └── API_CONFIG.md              # API configuration guide
│
├── examples/                       # Example files
│   └── media_data.json.example    # Empty data structure
│
├── screenshots/                    # Screenshots for README
│   └── README.md                  # Screenshot guidelines
│
├── .gitignore                      # Git ignore rules
├── CONTRIBUTING.md                 # Contribution guidelines
├── GIT_SETUP.md                   # First-time Git setup guide
├── LICENSE                         # MIT License
├── README.md                       # Main repository README
│
├── media_tracker.py               # Main TUI application
├── html_generator.py              # Terminal theme HTML generator
├── html_generator_excel.py        # Excel theme HTML generator
│
├── setup.sh                       # Linux setup script
├── setup_arch.sh                  # Arch Linux setup script
├── deploy.sh                      # Neocities deployment script
│
└── requirements.txt               # Python dependencies
```

## File Descriptions

### Core Application

**media_tracker.py**
- Main TUI application
- Menu-driven interface
- API integration (TMDb, Google Books)
- Progress tracking logic
- HTML generation trigger

**html_generator.py**
- Generates Terminal-style HTML
- Green CRT aesthetic
- Scanline effects
- ASCII progress bars

**html_generator_excel.py**
- Generates Excel-style HTML
- Windows 95 theme
- Spreadsheet grid layout
- Classic UI elements

### Setup Scripts

**setup.sh**
- Generic Linux setup
- Installs Python dependencies
- Creates initial data file
- Sets permissions

**setup_arch.sh**
- Arch Linux specific setup
- Uses `--user` flag for pip
- Optimized for Arch workflow

**deploy.sh**
- Neocities deployment
- Requires neocities gem
- API key configuration

### Configuration Files

**.gitignore**
- Ignores `media_data.json` (user data)
- Ignores Python cache
- Ignores virtual environments
- Ignores generated HTML

**requirements.txt**
- `rich` - Terminal UI library
- `requests` - HTTP requests for APIs

### Documentation

**README.md** (root)
- Project overview
- Quick start
- Features
- Installation
- Links to detailed docs

**docs/README.md**
- Complete user guide
- All features explained
- Customization options
- Troubleshooting

**docs/QUICKSTART.md**
- 3-step setup
- First movie walkthrough
- Basic usage

**docs/STYLE_GUIDE.md**
- Terminal vs Excel comparison
- Customization guide
- Color schemes

**docs/ARCH_SETUP.md**
- Arch-specific setup
- System packages vs pip
- Systemd service examples
- PKGBUILD template

**docs/API_CONFIG.md**
- TMDb API setup
- Google Books API
- Rate limits
- Security practices

### GitHub Files

**.github/ISSUE_TEMPLATE/bug_report.md**
- Structured bug reports
- Environment info template

**.github/ISSUE_TEMPLATE/feature_request.md**
- Feature request format
- Use case documentation

**.github/pull_request_template.md**
- PR checklist
- Testing requirements
- Documentation updates

### Other Files

**CONTRIBUTING.md**
- Contribution guidelines
- Code style
- Development setup
- PR process

**GIT_SETUP.md**
- First commit checklist
- GitHub setup steps
- Branching strategy
- Release process

**LICENSE**
- MIT License
- Open source

**examples/media_data.json.example**
- Empty data structure
- No dummy data
- Clean template

## Generated Files (Not in Repo)

These files are created during use and ignored by Git:

```
media_data.json           # User's tracking data
index.html               # Generated HTML page
backups/                 # Backup directory
__pycache__/            # Python cache
venv/                   # Virtual environment
```

## Dependencies

### Python (≥3.9)
- **rich** - Terminal formatting and TUI components
- **requests** - HTTP client for API calls

### Optional
- **Ruby** - For neocities gem (deployment)
- **neocities gem** - CLI deployment tool

## Usage Flow

```
1. Clone repository
2. Run setup.sh or setup_arch.sh
3. Run media_tracker.py
4. Use TUI to add/update media
5. Generate HTML (choose style)
6. Deploy to web host
```

## Data Flow

```
User Input
    ↓
media_tracker.py
    ↓
API Call (TMDb/Google Books)
    ↓
media_data.json (saved)
    ↓
html_generator.py or html_generator_excel.py
    ↓
index.html (generated)
    ↓
Web Host (Neocities, etc.)
```

## Development Workflow

1. Fork repository
2. Clone your fork
3. Create feature branch
4. Make changes
5. Test locally
6. Commit with clear message
7. Push to your fork
8. Open pull request

## Maintenance Tasks

**Regular**:
- Update dependencies
- Review issues/PRs
- Update documentation

**Periodic**:
- Create releases
- Update screenshots
- Review security

**As Needed**:
- Add features
- Fix bugs
- Improve docs

---

**Everything is organized for easy contribution and maintenance!** 🚀
