#!/bin/bash
# Media Tracker Setup - Arch Linux Edition
# btw i use arch

echo "🎬 Media Progress Tracker - Arch Linux Setup"
echo "=============================================="
echo ""

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 not found."
    echo "Install with: sudo pacman -S python"
    exit 1
fi

echo "✓ Python 3 found"

# Check pip
if ! command -v pip &> /dev/null; then
    echo "⚠️  pip not found, installing..."
    sudo pacman -S python-pip --noconfirm
fi

# Install dependencies
echo ""
echo "📦 Installing Python dependencies..."

# On Arch, prefer system packages when available
if pacman -Qs python-requests > /dev/null ; then
    echo "✓ python-requests already installed (system package)"
else
    echo "Installing python-requests..."
    pip install --user requests
fi

# Rich is usually not in official repos, use pip
echo "Installing rich (via pip)..."
pip install --user rich

echo "✓ Dependencies installed"

# Make scripts executable
echo ""
echo "🔧 Setting permissions..."
chmod +x media_tracker.py
chmod +x deploy.sh
echo "✓ Permissions set"

# Create initial data file if it doesn't exist
if [ ! -f "media_data.json" ]; then
    echo ""
    echo "📄 Creating initial data file..."
    cp examples/media_data.json.example media_data.json
    echo "✓ Data file created"
fi

echo ""
echo "✅ Setup complete!"
echo ""
echo "To start tracking, run:"
echo "  ./media_tracker.py"
echo ""
echo "btw, nice choice of distro 😎"
echo ""
