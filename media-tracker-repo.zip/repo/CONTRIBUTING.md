# Contributing to Media Progress Tracker

First off, thanks for taking the time to contribute! 🎉

## Code of Conduct

Be respectful, inclusive, and constructive. We're all here to make cool stuff.

## How Can I Contribute?

### Reporting Bugs

Before creating bug reports, please check existing issues. When creating a bug report, include:

- **Description** - Clear description of the bug
- **Steps to reproduce** - Detailed steps
- **Expected behavior** - What should happen
- **Actual behavior** - What actually happens
- **Environment** - OS, Python version, etc.
- **Screenshots** - If applicable

### Suggesting Features

Feature requests are welcome! Please include:

- **Use case** - Why is this needed?
- **Proposed solution** - How should it work?
- **Alternatives** - Other approaches you've considered

### Pull Requests

1. **Fork the repo** and create your branch from `main`
2. **Make your changes** - Follow the code style
3. **Test your changes** - Make sure everything works
4. **Update documentation** - If needed
5. **Submit PR** - With clear description

## Development Setup

```bash
# Clone your fork
git clone https://github.com/yourusername/media-tracker.git
cd media-tracker

# Create virtual environment (recommended)
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Make your changes
# ...

# Test
./media_tracker.py
```

## Code Style

- **Python**: Follow PEP 8
- **Comments**: Explain the "why", not the "what"
- **Functions**: Keep them focused and documented
- **Commits**: Use clear, descriptive messages

### Commit Messages

```
feat: Add support for manga tracking
fix: Resolve TMDb API timeout issue
docs: Update installation instructions
style: Format code with black
refactor: Simplify progress calculation
test: Add unit tests for API calls
```

## Project Structure

```
media-tracker/
├── media_tracker.py           # Main TUI application
├── html_generator.py          # Terminal theme generator
├── html_generator_excel.py    # Excel theme generator
├── setup.sh                   # Generic Linux setup
├── setup_arch.sh             # Arch Linux setup
├── deploy.sh                 # Deployment script
├── docs/                     # Documentation
│   ├── README.md            # User guide
│   ├── QUICKSTART.md        # Quick start
│   ├── STYLE_GUIDE.md       # Theme comparison
│   ├── ARCH_SETUP.md        # Arch-specific docs
│   └── API_CONFIG.md        # API configuration
├── examples/                 # Example files
│   └── media_data.json.example
├── tests/                    # Unit tests (future)
├── LICENSE                   # MIT License
├── README.md                 # Repository README
├── CONTRIBUTING.md          # This file
└── requirements.txt         # Python dependencies
```

## What to Contribute?

### Good First Issues

- Documentation improvements
- Bug fixes
- Adding comments to code
- UI/UX improvements
- New color schemes

### Bigger Projects

- New API integrations (Trakt, Anilist, etc.)
- Additional HTML themes
- Import/export features
- Statistics and charts
- Unit tests

## Testing

Currently, the project uses manual testing. Run through these scenarios:

1. Add movie with valid title
2. Add movie with invalid title
3. Update progress
4. Generate HTML (both themes)
5. Test on different Python versions (3.9, 3.10, 3.11+)
6. Test on different Linux distros

Future: We'll add automated tests using pytest.

## Documentation

When adding features, update:

- README.md (if user-facing)
- Relevant docs in `docs/`
- Code comments
- Help text in the TUI

## API Keys

**Important**: Never commit API keys!

- Use environment variables
- Add to .gitignore
- Provide example configs

The TMDb key in the code is a read-only demo key that's safe to share.

## Questions?

Feel free to open an issue with the `question` label!

## Recognition

Contributors will be added to the README. Thank you! 🙏

---

**Happy coding!** 🎬📺📚
