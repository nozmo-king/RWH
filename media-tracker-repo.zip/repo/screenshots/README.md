# Screenshots

Add preview images here for the README.

## Recommended Screenshots

1. **terminal-tui.png** - TUI menu interface
2. **terminal-style.png** - Terminal HTML theme preview
3. **excel-style.png** - Excel HTML theme preview
4. **mobile-preview.png** - Mobile responsive view

## How to Create Screenshots

### TUI Screenshot
```bash
./media_tracker.py
# Take screenshot of the menu
```

### HTML Screenshots
```bash
# Generate HTML
./media_tracker.py
# Select option 6, choose a style

# Open in browser
firefox index.html  # or your browser

# Take screenshot
```

## Usage in README

Reference in main README.md:
```markdown
![Terminal Style](screenshots/terminal-style.png)
![Excel Style](screenshots/excel-style.png)
```

## Image Guidelines

- **Format**: PNG preferred
- **Size**: Max 1920x1080
- **Compression**: Optimize with `optipng` or similar
- **Names**: Use kebab-case (lowercase-with-dashes)
