# 🚀 QUICK START GUIDE

## Get Started in 3 Steps

### Step 1: Upload to Your Server

Upload these files to your server (via SCP, SFTP, or your hosting panel):

```
media_tracker.py       (Main TUI app)
html_generator.py      (HTML generator)
setup.sh              (Setup script)
deploy.sh             (Neocities deploy)
README.md             (Full documentation)
```

### Step 2: Run Setup

SSH into your server and run:

```bash
cd /path/to/media_tracker
./setup.sh
```

This will:
- Install Python dependencies (rich, requests)
- Set file permissions
- Create initial data file

### Step 3: Start Tracking!

```bash
./media_tracker.py
```

You'll see a menu like this:

```
╔════════════════════════════════════════════════╗
║       MEDIA PROGRESS TRACKER v1.0              ║
╚════════════════════════════════════════════════╝

Main Menu:

1. Add Movie
2. Add TV Show  
3. Add Book
4. Update Progress
5. View All Media
6. Generate HTML
7. Deploy to Neocities
0. Exit

Select option:
```

---

## Your First Movie

Let's add your first movie (like Gummo):

1. **Select option 1** (Add Movie)
2. **Type:** `Gummo`
3. The app will search TMDb and show:
   ```
   Found: Gummo (1997)
   Runtime: 89 minutes
   Director: Harmony Korine
   
   Is this correct? (y/n):
   ```
4. **Press Y**
5. **Enter minutes watched:** `53` (or however much you've watched)
6. **Done!** Movie is added with 59.6% progress

---

## Update Your Progress

When you watch more:

1. **Select option 4** (Update Progress)
2. **Choose** the movie from the list
3. **Enter new minutes:** `70`
4. Progress auto-updates to 78.7%

---

## Generate Your Website

1. **Select option 6** (Generate HTML)
2. Creates `index.html` with retro terminal styling
3. **Preview it:** Open `demo.html` in your browser to see what it looks like!

---

## Deploy to Neocities

### Easy Way (Manual Upload):

1. Go to https://neocities.org
2. Create account (free)
3. Click "Edit Site"
4. Upload your `index.html`
5. View at: `https://your-username.neocities.org`

### Advanced Way (CLI):

1. Get API key from https://neocities.org/settings
2. Edit `deploy.sh` and add your key
3. Run: `./deploy.sh`

---

## Daily Workflow

```bash
# SSH into your server
ssh user@yourserver.com

# Run tracker
./media_tracker.py

# Add/update your progress
# Select option 4, update items

# Generate new HTML
# Select option 6

# Deploy (manual or automatic)
./deploy.sh
```

---

## Tips

**Add shortcut to ~/.bashrc:**
```bash
alias tracker='cd ~/media_tracker && ./media_tracker.py'
```

Now just type `tracker` from anywhere!

**Backup your data:**
```bash
cp media_data.json media_data_backup.json
```

---

## Troubleshooting

**"Module not found"**
```bash
pip install rich requests --break-system-packages
```

**"Permission denied"**
```bash
chmod +x media_tracker.py setup.sh deploy.sh
```

**"Can't connect to API"**
- Check internet connection
- TMDb API is already configured with key

---

## What's Next?

- Add all your current movies/shows/books
- Update progress as you watch/read
- Generate HTML daily/weekly
- Share your tracker URL with friends!

---

## Need Help?

Read the full `README.md` for:
- Customizing colors
- Modifying progress bars
- API configuration
- Advanced features

**Happy tracking!** 🎬📺📚
