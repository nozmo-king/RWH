# Media Progress Tracker TUI

A terminal-based media tracker with automatic API lookups and static HTML generation.

## Features

- 📽️ **Movies** - Auto-fetch runtime and director from TMDb
- 📺 **TV Shows** - Track episodes with season/episode info
- 📚 **Books** - Auto-fetch page count and author from Google Books
- 📊 **Progress tracking** - Automatic percentage calculation
- 🎨 **Retro HTML** - Generates terminal-styled static page
- 🚀 **Neocities ready** - Deploy your tracker online

## Quick Start

### 1. Upload to Your Server

Upload these files to your server:
- `media_tracker.py` (main TUI app)
- `html_generator.py` (HTML generator)
- `deploy.sh` (deployment script)

### 2. Install Dependencies

```bash
# The app will auto-install packages, but you can also run:
pip install rich requests --break-system-packages
```

### 3. Make Executable

```bash
chmod +x media_tracker.py
chmod +x deploy.sh
```

### 4. Run the TUI

```bash
./media_tracker.py
```

## Usage

### Main Menu

```
1. Add Movie       - Search and add a movie
2. Add TV Show     - Add a TV episode
3. Add Book        - Search and add a book
4. Update Progress - Update your watch/read progress
5. View All Media  - See everything you're tracking
6. Generate HTML   - Create static HTML page
7. Deploy          - Push to Neocities
0. Exit            - Quit
```

### Adding Media

**Movies:**
1. Select "Add Movie"
2. Enter movie title (e.g., "Inception")
3. App fetches runtime and director automatically
4. Enter how many minutes you've watched
5. Done!

**TV Shows:**
1. Select "Add TV Show"
2. Enter show title
3. Enter season and episode numbers
4. Enter episode runtime
5. Enter minutes watched

**Books:**
1. Select "Add Book"
2. Enter book title
3. App fetches page count and author
4. Enter your current page number

### Updating Progress

1. Select "Update Progress"
2. Choose item from the list
3. Enter new position (minutes or page number)
4. Progress automatically recalculates

### Generating HTML

1. Select "Generate HTML"
2. Creates `index.html` with retro terminal styling
3. File is ready to upload to Neocities or any web host

## Deploying to Neocities

### Option 1: Manual Upload (Easiest)

1. Generate HTML in the TUI (option 6)
2. Go to https://neocities.org
3. Log in to your account
4. Click "Edit Site"
5. Upload `index.html`
6. Done! View at https://your-username.neocities.org

### Option 2: CLI Upload (Advanced)

1. Get your Neocities API key from https://neocities.org/settings
2. Install Neocities CLI:
   ```bash
   gem install neocities
   ```
3. Edit `deploy.sh` and add your API key
4. Run:
   ```bash
   ./deploy.sh
   ```

### Option 3: Auto-deploy with Cron (Pro)

Add to crontab to auto-deploy every hour:

```bash
0 * * * * cd /path/to/tracker && ./deploy.sh
```

## File Structure

```
media_tracker/
├── media_tracker.py    # Main TUI application
├── html_generator.py   # HTML generation
├── deploy.sh          # Deployment script
├── media_data.json    # Your data (created automatically)
└── index.html         # Generated HTML (created when you generate)
```

## Data Storage

All data is stored in `media_data.json`:

```json
{
  "movies": [
    {
      "title": "Inception",
      "year": "2010",
      "director": "Christopher Nolan",
      "total": 148,
      "current": 60,
      "progress": 40.5,
      "completed": false
    }
  ],
  "tv_shows": [...],
  "books": [...]
}
```

## Customization

### Change HTML Colors

Edit `html_generator.py` line 26-28:

```python
background-color: #0a0e0f;  # Dark background
color: #00ff41;             # Green text (Matrix style)
```

Popular terminal color schemes:
- **Green CRT**: `#00ff41` (default)
- **Amber**: `#ffb000`
- **Blue IBM**: `#00aaff`
- **White**: `#ffffff`

### Modify Progress Bar

Edit `html_generator.py` line 10-11:

```python
filled = "█"  # Change to: ▓ ▒ ░ # = ■ etc.
empty = "░"   # Change to: - _ . ═ etc.
```

## API Keys

The TMDb API key is included and ready to use. If you need your own:

1. Sign up at https://www.themoviedb.org
2. Go to Settings → API
3. Request API key
4. Replace token in `media_tracker.py` line 28

Google Books API requires no key!

## Troubleshooting

### "Module not found" error

```bash
pip install rich requests --break-system-packages
```

### Can't connect to APIs

Check internet connection. The app needs to reach:
- `api.themoviedb.org` (movies/TV)
- `googleapis.com` (books)

### Permission denied

```bash
chmod +x media_tracker.py
```

### HTML looks broken

Make sure you generated HTML after adding data:
1. Add some media items
2. Select "Generate HTML" from menu
3. Upload the new `index.html`

## Tips

- **Batch updates**: Update multiple items at once by running option 4 repeatedly
- **Backup data**: Copy `media_data.json` regularly
- **SSH shortcut**: Add alias to your `.bashrc`:
  ```bash
  alias tracker='cd ~/media_tracker && ./media_tracker.py'
  ```
- **Quick deploy**: Generate HTML and deploy in one go:
  ```bash
  ./media_tracker.py  # Generate HTML (option 6)
  ./deploy.sh         # Deploy
  ```

## Support

- TMDb API: https://developers.themoviedb.org
- Google Books API: https://developers.google.com/books
- Neocities: https://neocities.org/tutorials

## License

Free to use and modify. Built with ❤️ for personal media tracking.

---

**Happy tracking!** 🎬📺📚
