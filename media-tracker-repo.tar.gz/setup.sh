#!/bin/bash
# Quick Setup Script for Media Tracker

echo "🎬 Media Progress Tracker - Setup"
echo "=================================="
echo ""

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 not found. Please install Python 3."
    exit 1
fi

echo "✓ Python 3 found"

# Install dependencies
echo ""
echo "📦 Installing dependencies..."
pip install rich requests --break-system-packages 2>/dev/null

if [ $? -eq 0 ]; then
    echo "✓ Dependencies installed"
else
    echo "⚠️  Could not install via pip, will try during runtime"
fi

# Make scripts executable
echo ""
echo "🔧 Setting permissions..."
chmod +x media_tracker.py
chmod +x deploy.sh
echo "✓ Permissions set"

# Create initial data file if it doesn't exist
if [ ! -f "media_data.json" ]; then
    echo ""
    echo "📄 Creating initial data file..."
    cp examples/media_data.json.example media_data.json
    echo "✓ Data file created"
fi

echo ""
echo "✅ Setup complete!"
echo ""
echo "To start tracking, run:"
echo "  ./media_tracker.py"
echo ""
echo "For help, see:"
echo "  cat README.md"
echo ""
