#!/usr/bin/env python3
"""
Media Progress Tracker - TUI Application
Track movies, TV shows, and books with automatic API lookups
"""

import json
import os
import sys
from datetime import datetime
from typing import Dict, List, Optional
import requests

try:
    from rich.console import Console
    from rich.table import Table
    from rich.prompt import Prompt, IntPrompt, Confirm
    from rich.panel import Panel
    from rich import box
except ImportError:
    print("Installing required packages...")
    import platform
    import sys
    
    # Detect OS and use appropriate pip command
    if "arch" in platform.platform().lower():
        # Arch Linux - use --user flag
        os.system(f"{sys.executable} -m pip install --user rich requests")
    else:
        # Other distros - try --break-system-packages
        os.system(f"{sys.executable} -m pip install rich requests --break-system-packages")
    
    from rich.console import Console
    from rich.table import Table
    from rich.prompt import Prompt, IntPrompt, Confirm
    from rich.panel import Panel
    from rich import box

console = Console()

# API Configuration
TMDB_TOKEN = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJlNGM1NGY4NmE1NDA4Yjg5MWJjMDBhY2E0YzZkODk4YiIsIm5iZiI6MTc1OTc0ODM3Ny43ODksInN1YiI6IjY4ZTNhMTE5MDRhZGY4NjgzOGY4MWI1OCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.BVLdENlMmGZhk-_fkSyIMueBeUQT8PtlHCsWKBwzql4"
DATA_FILE = "media_data.json"
HTML_OUTPUT = "index.html"


class MediaTracker:
    def __init__(self):
        self.data = self.load_data()
    
    def load_data(self) -> Dict:
        """Load media data from JSON file"""
        if os.path.exists(DATA_FILE):
            with open(DATA_FILE, 'r') as f:
                return json.load(f)
        return {"movies": [], "tv_shows": [], "books": []}
    
    def save_data(self):
        """Save media data to JSON file"""
        with open(DATA_FILE, 'w') as f:
            json.dump(self.data, f, indent=2)
        console.print("[green]✓ Data saved successfully[/green]")
    
    def search_movie(self, title: str) -> Optional[Dict]:
        """Search for movie using TMDb API"""
        console.print(f"[cyan]Searching for movie: {title}...[/cyan]")
        url = "https://api.themoviedb.org/3/search/movie"
        headers = {
            "Authorization": f"Bearer {TMDB_TOKEN}",
            "accept": "application/json"
        }
        params = {"query": title, "include_adult": "false"}
        
        try:
            response = requests.get(url, headers=headers, params=params)
            response.raise_for_status()
            results = response.json().get("results", [])
            
            if not results:
                console.print("[yellow]No results found[/yellow]")
                return None
            
            # Get full details including runtime
            movie_id = results[0]["id"]
            detail_url = f"https://api.themoviedb.org/3/movie/{movie_id}"
            detail_response = requests.get(detail_url, headers=headers)
            movie = detail_response.json()
            
            return {
                "title": movie.get("title"),
                "year": movie.get("release_date", "")[:4],
                "runtime": movie.get("runtime", 0),
                "director": self.get_director(movie_id),
            }
        except Exception as e:
            console.print(f"[red]Error fetching movie data: {e}[/red]")
            return None
    
    def get_director(self, movie_id: int) -> str:
        """Get director name for a movie"""
        url = f"https://api.themoviedb.org/3/movie/{movie_id}/credits"
        headers = {
            "Authorization": f"Bearer {TMDB_TOKEN}",
            "accept": "application/json"
        }
        try:
            response = requests.get(url, headers=headers)
            crew = response.json().get("crew", [])
            for person in crew:
                if person.get("job") == "Director":
                    return person.get("name", "Unknown")
        except:
            pass
        return "Unknown"
    
    def search_tv_show(self, title: str) -> Optional[Dict]:
        """Search for TV show using TMDb API"""
        console.print(f"[cyan]Searching for TV show: {title}...[/cyan]")
        url = "https://api.themoviedb.org/3/search/tv"
        headers = {
            "Authorization": f"Bearer {TMDB_TOKEN}",
            "accept": "application/json"
        }
        params = {"query": title}
        
        try:
            response = requests.get(url, headers=headers, params=params)
            results = response.json().get("results", [])
            
            if not results:
                console.print("[yellow]No results found[/yellow]")
                return None
            
            show = results[0]
            return {
                "title": show.get("name"),
                "year": show.get("first_air_date", "")[:4],
            }
        except Exception as e:
            console.print(f"[red]Error fetching TV show data: {e}[/red]")
            return None
    
    def search_book(self, title: str) -> Optional[Dict]:
        """Search for book using Google Books API"""
        console.print(f"[cyan]Searching for book: {title}...[/cyan]")
        url = "https://www.googleapis.com/books/v1/volumes"
        params = {"q": title}
        
        try:
            response = requests.get(url, params=params)
            results = response.json().get("items", [])
            
            if not results:
                console.print("[yellow]No results found[/yellow]")
                return None
            
            book = results[0]["volumeInfo"]
            authors = book.get("authors", ["Unknown"])
            
            return {
                "title": book.get("title"),
                "author": authors[0] if authors else "Unknown",
                "pages": book.get("pageCount", 0),
            }
        except Exception as e:
            console.print(f"[red]Error fetching book data: {e}[/red]")
            return None
    
    def add_movie(self):
        """Add a new movie"""
        console.clear()
        console.print(Panel("[bold cyan]Add Movie[/bold cyan]", box=box.DOUBLE))
        
        title = Prompt.ask("Enter movie title")
        movie_data = self.search_movie(title)
        
        if not movie_data:
            return
        
        console.print(f"\n[green]Found:[/green] {movie_data['title']} ({movie_data['year']})")
        console.print(f"[green]Runtime:[/green] {movie_data['runtime']} minutes")
        console.print(f"[green]Director:[/green] {movie_data['director']}")
        
        if not Confirm.ask("\nIs this correct?"):
            return
        
        current = IntPrompt.ask("How many minutes have you watched?", default=0)
        
        entry = {
            "id": len(self.data["movies"]) + 1,
            "title": movie_data["title"],
            "year": movie_data["year"],
            "medium": "movie",
            "director": movie_data["director"],
            "total": movie_data["runtime"],
            "current": current,
            "progress": round((current / movie_data["runtime"]) * 100, 1) if movie_data["runtime"] > 0 else 0,
            "completed": current >= movie_data["runtime"],
            "added": datetime.now().isoformat(),
            "updated": datetime.now().isoformat()
        }
        
        self.data["movies"].append(entry)
        self.save_data()
        console.print(f"\n[green]✓ Added: {entry['title']}[/green]")
        Prompt.ask("\nPress Enter to continue")
    
    def add_tv_show(self):
        """Add a new TV show"""
        console.clear()
        console.print(Panel("[bold cyan]Add TV Show[/bold cyan]", box=box.DOUBLE))
        
        title = Prompt.ask("Enter TV show title")
        show_data = self.search_tv_show(title)
        
        if not show_data:
            return
        
        console.print(f"\n[green]Found:[/green] {show_data['title']} ({show_data['year']})")
        
        season = IntPrompt.ask("Season number")
        episode = IntPrompt.ask("Episode number")
        runtime = IntPrompt.ask("Episode runtime (minutes)")
        current = IntPrompt.ask("How many minutes watched?", default=0)
        
        entry = {
            "id": len(self.data["tv_shows"]) + 1,
            "title": f"{show_data['title']} S{season:02d}E{episode:02d}",
            "year": show_data['year'],
            "medium": "tv",
            "season": season,
            "episode": episode,
            "total": runtime,
            "current": current,
            "progress": round((current / runtime) * 100, 1) if runtime > 0 else 0,
            "completed": current >= runtime,
            "added": datetime.now().isoformat(),
            "updated": datetime.now().isoformat()
        }
        
        self.data["tv_shows"].append(entry)
        self.save_data()
        console.print(f"\n[green]✓ Added: {entry['title']}[/green]")
        Prompt.ask("\nPress Enter to continue")
    
    def add_book(self):
        """Add a new book"""
        console.clear()
        console.print(Panel("[bold cyan]Add Book[/bold cyan]", box=box.DOUBLE))
        
        title = Prompt.ask("Enter book title")
        book_data = self.search_book(title)
        
        if not book_data:
            return
        
        console.print(f"\n[green]Found:[/green] {book_data['title']}")
        console.print(f"[green]Author:[/green] {book_data['author']}")
        console.print(f"[green]Pages:[/green] {book_data['pages']}")
        
        if not Confirm.ask("\nIs this correct?"):
            return
        
        current = IntPrompt.ask("What page are you on?", default=0)
        
        entry = {
            "id": len(self.data["books"]) + 1,
            "title": book_data["title"],
            "medium": "book",
            "author": book_data["author"],
            "total": book_data["pages"],
            "current": current,
            "progress": round((current / book_data["pages"]) * 100, 1) if book_data["pages"] > 0 else 0,
            "completed": current >= book_data["pages"],
            "added": datetime.now().isoformat(),
            "updated": datetime.now().isoformat()
        }
        
        self.data["books"].append(entry)
        self.save_data()
        console.print(f"\n[green]✓ Added: {entry['title']}[/green]")
        Prompt.ask("\nPress Enter to continue")
    
    def update_progress(self):
        """Update progress for an existing item"""
        console.clear()
        console.print(Panel("[bold cyan]Update Progress[/bold cyan]", box=box.DOUBLE))
        
        all_items = []
        for movie in self.data["movies"]:
            if not movie["completed"]:
                all_items.append(("movie", movie))
        for show in self.data["tv_shows"]:
            if not show["completed"]:
                all_items.append(("tv", show))
        for book in self.data["books"]:
            if not book["completed"]:
                all_items.append(("book", book))
        
        if not all_items:
            console.print("[yellow]No items in progress[/yellow]")
            Prompt.ask("\nPress Enter to continue")
            return
        
        console.print("\n[bold]In Progress:[/bold]\n")
        for idx, (media_type, item) in enumerate(all_items, 1):
            console.print(f"{idx}. {item['title']} - {item['progress']}%")
        
        choice = IntPrompt.ask("\nSelect item number (0 to cancel)", default=0)
        
        if choice < 1 or choice > len(all_items):
            return
        
        media_type, item = all_items[choice - 1]
        
        console.print(f"\n[cyan]{item['title']}[/cyan]")
        console.print(f"Current: {item['current']} / {item['total']}")
        
        if media_type == "book":
            new_current = IntPrompt.ask("New page number")
        else:
            new_current = IntPrompt.ask("New minutes watched")
        
        item["current"] = new_current
        item["progress"] = round((new_current / item["total"]) * 100, 1)
        item["completed"] = new_current >= item["total"]
        item["updated"] = datetime.now().isoformat()
        
        self.save_data()
        console.print(f"\n[green]✓ Updated: {item['title']} to {item['progress']}%[/green]")
        Prompt.ask("\nPress Enter to continue")
    
    def view_all(self):
        """View all tracked media"""
        console.clear()
        console.print(Panel("[bold cyan]All Media[/bold cyan]", box=box.DOUBLE))
        
        # Movies
        if self.data["movies"]:
            table = Table(title="Movies", box=box.SIMPLE)
            table.add_column("Title", style="cyan")
            table.add_column("Progress", style="green")
            table.add_column("Status")
            
            for movie in self.data["movies"]:
                status = "✓" if movie["completed"] else "⏳"
                table.add_row(
                    f"{movie['title']} ({movie['year']})",
                    f"{movie['progress']}%",
                    status
                )
            console.print(table)
            console.print()
        
        # TV Shows
        if self.data["tv_shows"]:
            table = Table(title="TV Shows", box=box.SIMPLE)
            table.add_column("Title", style="cyan")
            table.add_column("Progress", style="green")
            table.add_column("Status")
            
            for show in self.data["tv_shows"]:
                status = "✓" if show["completed"] else "⏳"
                table.add_row(
                    show['title'],
                    f"{show['progress']}%",
                    status
                )
            console.print(table)
            console.print()
        
        # Books
        if self.data["books"]:
            table = Table(title="Books", box=box.SIMPLE)
            table.add_column("Title", style="cyan")
            table.add_column("Progress", style="green")
            table.add_column("Status")
            
            for book in self.data["books"]:
                status = "✓" if book["completed"] else "⏳"
                table.add_row(
                    book['title'],
                    f"{book['progress']}%",
                    status
                )
            console.print(table)
        
        Prompt.ask("\nPress Enter to continue")
    
    def generate_html(self):
        """Generate static HTML page"""
        console.clear()
        console.print(Panel("[bold cyan]Generate HTML[/bold cyan]", box=box.DOUBLE))
        
        console.print("\n[bold]Choose Style:[/bold]\n")
        console.print("1. Terminal (Green CRT / Matrix style)")
        console.print("2. Excel (Classic spreadsheet style)")
        
        choice = Prompt.ask("\nSelect style", choices=["1", "2"], default="1")
        
        if choice == "1":
            from html_generator import generate_html_page
            console.print("\n[cyan]Generating Terminal-style HTML...[/cyan]")
        else:
            from html_generator_excel import generate_html_page
            console.print("\n[cyan]Generating Excel-style HTML...[/cyan]")
        
        generate_html_page(self.data, HTML_OUTPUT)
        console.print(f"[green]✓ Generated: {HTML_OUTPUT}[/green]")
        Prompt.ask("\nPress Enter to continue")
    
    def main_menu(self):
        """Display main menu"""
        while True:
            console.clear()
            console.print(Panel.fit(
                "[bold cyan]MEDIA PROGRESS TRACKER[/bold cyan]\n"
                "[dim]Track movies, TV shows, and books[/dim]",
                box=box.DOUBLE
            ))
            
            console.print("\n[bold]Main Menu:[/bold]\n")
            console.print("1. Add Movie")
            console.print("2. Add TV Show")
            console.print("3. Add Book")
            console.print("4. Update Progress")
            console.print("5. View All Media")
            console.print("6. Generate HTML")
            console.print("7. Deploy to Neocities")
            console.print("0. Exit")
            
            choice = Prompt.ask("\nSelect option", choices=["0","1","2","3","4","5","6","7"])
            
            if choice == "0":
                console.print("\n[cyan]Goodbye![/cyan]")
                break
            elif choice == "1":
                self.add_movie()
            elif choice == "2":
                self.add_tv_show()
            elif choice == "3":
                self.add_book()
            elif choice == "4":
                self.update_progress()
            elif choice == "5":
                self.view_all()
            elif choice == "6":
                self.generate_html()
            elif choice == "7":
                self.deploy_neocities()
    
    def deploy_neocities(self):
        """Deploy to Neocities"""
        console.print("[yellow]Neocities deployment requires setup. See deploy.sh[/yellow]")
        Prompt.ask("\nPress Enter to continue")


if __name__ == "__main__":
    tracker = MediaTracker()
    tracker.main_menu()
