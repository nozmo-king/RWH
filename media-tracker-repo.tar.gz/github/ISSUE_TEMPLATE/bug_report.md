---
name: Bug Report
about: Report a bug or issue
title: '[BUG] '
labels: bug
assignees: ''
---

## Description
A clear description of the bug.

## Steps to Reproduce
1. Run `./media_tracker.py`
2. Select option...
3. Enter...
4. See error

## Expected Behavior
What should happen.

## Actual Behavior
What actually happens.

## Environment
- **OS**: (e.g., Arch Linux, Ubuntu 22.04)
- **Python Version**: (run `python --version`)
- **Installation Method**: (setup.sh, manual, etc.)

## Screenshots
If applicable, add screenshots.

## Additional Context
Any other relevant information.
