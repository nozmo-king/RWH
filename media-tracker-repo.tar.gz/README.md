# Media Progress Tracker

A terminal-based media tracker with automatic API integration and beautiful retro HTML generation. Track movies, TV shows, and books with automatic progress calculation and deploy to static sites.

![Version](https://img.shields.io/badge/version-1.0.0-blue)
![License](https://img.shields.io/badge/license-MIT-green)
![Python](https://img.shields.io/badge/python-3.9%2B-blue)

## 🎬 Features

- **📽️ Movie Tracking** - Auto-fetch runtime and director from TMDb API
- **📺 TV Show Tracking** - Track episodes with season/episode info
- **📚 Book Tracking** - Auto-fetch page count and author from Google Books API
- **📊 Automatic Progress** - Calculate percentages and completion automatically
- **🎨 Dual HTML Themes**:
  - **Terminal Style** - Green CRT / Matrix aesthetic with scanlines
  - **Excel Style** - Classic Windows 95 spreadsheet look
- **🚀 Static Site Generation** - Deploy to Neocities, GitHub Pages, or any host
- **💾 Simple Storage** - JSON-based, easy to backup and version control
- **🐧 Linux Ready** - Works on any Linux distro (including Arch btw)

## 📸 Preview

### Terminal Style (Green CRT)
```
╔════════════════════════════════════════════════╗
║       MEDIA PROGRESS TRACKER v1.0              ║
║       [user@tracker ~]$                        ║
╚════════════════════════════════════════════════╝

> CURRENTLY WATCHING

[████████████░░░░░░░░] 60% Inception (2010)
148min total | 89min watched | Dir: Christopher Nolan
```

### Excel Style (Windows 95)
```
┌─────────────────────────────────────────────┐
│ 📊 Media Progress Tracker.xls        _ □ ✕ │
├─────────────────────────────────────────────┤
│  #  │ Title      │ Progress Bar  │ %      │
│ ────┼────────────┼──────────────┼───────  │
│  1  │ Inception  │ ■■■■■■□□□□□□ │ 60.0% │
```

## 🚀 Quick Start

### Installation

```bash
# Clone the repository
git clone https://github.com/YOUR-USERNAME/media-tracker.git
cd media-tracker

# Run setup (Linux/generic)
./setup.sh

# Or for Arch Linux
./setup_arch.sh

# Start tracking
./media_tracker.py
```

### First Use

1. Run `./media_tracker.py`
2. Select "Add Movie" (option 1)
3. Enter a movie title (e.g., "Inception")
4. App automatically fetches runtime and director
5. Enter how many minutes you've watched
6. Generate HTML (option 6) and choose your style
7. Deploy to your site!

## 📋 Requirements

- Python 3.9+
- `requests` library
- `rich` library (for TUI)

All dependencies auto-install on first run.

## 🎯 Usage

### Main Menu

```
1. Add Movie       - Search and add a movie
2. Add TV Show     - Add a TV episode
3. Add Book        - Search and add a book
4. Update Progress - Update your watch/read progress
5. View All Media  - See everything you're tracking
6. Generate HTML   - Create static HTML page
7. Deploy          - Push to Neocities
0. Exit            - Quit
```

### Adding Media

**Movies**: Enter title → App fetches runtime + director automatically  
**TV Shows**: Enter show title + season/episode → Add runtime and progress  
**Books**: Enter title → App fetches page count + author automatically

### Generating HTML

Choose between two styles:
1. **Terminal** - Retro green CRT aesthetic
2. **Excel** - Classic Windows 95 spreadsheet

Both are mobile-responsive and lightweight.

## 📚 Documentation

- [**Quick Start Guide**](docs/QUICKSTART.md) - Get up and running in 3 steps
- [**Full Documentation**](docs/README.md) - Complete user guide
- [**Style Guide**](docs/STYLE_GUIDE.md) - Compare HTML themes
- [**Arch Linux Setup**](docs/ARCH_SETUP.md) - Arch-specific instructions
- [**API Configuration**](docs/API_CONFIG.md) - Using your own API keys

## 🔧 Configuration

### Using Your Own API Keys

The project includes a working TMDb API key, but you can use your own:

1. Get API key from [TMDb](https://www.themoviedb.org/settings/api)
2. Edit `media_tracker.py` line 28
3. Replace the token with yours

Google Books API requires no key!

### Customizing HTML Themes

**Terminal Style**: Edit `html_generator.py`
```python
color: #00ff41;  # Change to #ffb000 for amber, #00aaff for blue
```

**Excel Style**: Edit `html_generator_excel.py`
```python
background-color: #c0c0c0;  # Classic gray or customize
```

## 🌐 Deployment

### Neocities (Recommended for beginners)

1. Generate HTML in the TUI (option 6)
2. Go to [Neocities](https://neocities.org)
3. Upload `index.html`
4. Done!

### GitHub Pages

```bash
# Initialize git (if not cloned)
git init
git add index.html
git commit -m "Add tracker page"
git push

# Enable Pages in repository settings
```

### Your Own Server

```bash
# Copy to web directory
scp index.html user@server:/var/www/html/tracker/
```

## 🤝 Contributing

Contributions welcome! Please read [CONTRIBUTING.md](CONTRIBUTING.md) first.

### Development Setup

```bash
# Clone repo
git clone https://github.com/YOUR-USERNAME/media-tracker.git
cd media-tracker

# Create virtual environment (optional)
python -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Run in dev mode
./media_tracker.py
```

### Roadmap

- [ ] Automatic Trakt.tv integration
- [ ] Multiple user profiles
- [ ] Statistics and charts
- [ ] Import from Letterboxd/Goodreads
- [ ] Dark mode for Excel theme
- [ ] More theme options (Amber terminal, IBM blue, etc.)

## 📄 License

MIT License - see [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- [TMDb API](https://www.themoviedb.org/documentation/api) - Movie and TV data
- [Google Books API](https://developers.google.com/books) - Book data
- [Rich](https://github.com/Textualize/rich) - Beautiful terminal UI
- Inspired by retro computing aesthetics and simple, effective tools

## 📞 Support

- 🐛 [Report Bug](https://github.com/YOUR-USERNAME/media-tracker/issues)
- 💡 [Request Feature](https://github.com/YOUR-USERNAME/media-tracker/issues)
- 📖 [Documentation](docs/)

## ⭐ Show Your Support

Give a ⭐️ if this project helped you!

---

**Built with ❤️ for tracking progress, one movie at a time.**
