#!/bin/bash
# Deploy to Neocities
# You'll need to install neocities CLI: gem install neocities

# Configuration
NEOCITIES_API_KEY="your_api_key_here"
HTML_FILE="index.html"

echo "📡 Deploying to Neocities..."

# Check if neocities CLI is installed
if ! command -v neocities &> /dev/null; then
    echo "❌ Neocities CLI not found!"
    echo "Install it with: gem install neocities"
    echo ""
    echo "Or manually upload $HTML_FILE to https://neocities.org"
    exit 1
fi

# Check if API key is set
if [ "$NEOCITIES_API_KEY" = "your_api_key_here" ]; then
    echo "⚠️  Please edit this script and add your Neocities API key"
    echo ""
    echo "Get your API key from: https://neocities.org/settings"
    echo ""
    echo "Alternative: Upload manually via web interface"
    exit 1
fi

# Upload file
neocities upload "$HTML_FILE" --api-key "$NEOCITIES_API_KEY"

if [ $? -eq 0 ]; then
    echo "✓ Successfully deployed!"
    echo "View at: https://your-username.neocities.org"
else
    echo "❌ Deployment failed"
    exit 1
fi
