"""
HTML Generator for Media Tracker - EXCEL STYLE
Creates a classic Excel 95/97 spreadsheet aesthetic
"""

from datetime import datetime
from typing import Dict


def create_progress_bar(progress: float, width: int = 20) -> str:
    """Create Excel-style progress bar"""
    filled = int((progress / 100) * width)
    empty = width - filled
    return "■" * filled + "□" * empty


def generate_html_page(data: Dict, output_file: str):
    """Generate static HTML page with Excel spreadsheet styling"""
    
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Media Progress Tracker</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            background-color: #c0c0c0;
            font-family: 'Arial', 'MS Sans Serif', sans-serif;
            padding: 20px;
            min-height: 100vh;
        }}
        
        .window {{
            max-width: 1000px;
            margin: 0 auto;
            background-color: #ffffff;
            border: 2px solid #000000;
            box-shadow: 
                inset -1px -1px 0 #808080,
                inset 1px 1px 0 #ffffff,
                2px 2px 5px rgba(0,0,0,0.3);
        }}
        
        .title-bar {{
            background: linear-gradient(90deg, #000080, #1084d0);
            color: white;
            padding: 4px 8px;
            font-weight: bold;
            font-size: 12px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }}
        
        .title-bar-text {{
            display: flex;
            align-items: center;
            gap: 5px;
        }}
        
        .title-bar-icon {{
            width: 16px;
            height: 16px;
            background: white;
            display: inline-block;
        }}
        
        .title-bar-controls {{
            display: flex;
            gap: 2px;
        }}
        
        .title-button {{
            width: 16px;
            height: 14px;
            background: #c0c0c0;
            border: 1px solid;
            border-color: #ffffff #000000 #000000 #ffffff;
            font-size: 10px;
            line-height: 12px;
            text-align: center;
            cursor: pointer;
        }}
        
        .menu-bar {{
            background-color: #c0c0c0;
            border-bottom: 1px solid #808080;
            padding: 2px 5px;
            font-size: 11px;
        }}
        
        .menu-item {{
            display: inline-block;
            padding: 2px 8px;
            cursor: pointer;
        }}
        
        .menu-item:hover {{
            background-color: #000080;
            color: white;
        }}
        
        .toolbar {{
            background-color: #c0c0c0;
            border-bottom: 1px solid #808080;
            padding: 4px;
            display: flex;
            gap: 2px;
        }}
        
        .toolbar-button {{
            background: #c0c0c0;
            border: 1px solid;
            border-color: #ffffff #000000 #000000 #ffffff;
            padding: 3px 8px;
            font-size: 10px;
            cursor: pointer;
        }}
        
        .toolbar-button:active {{
            border-color: #000000 #ffffff #ffffff #000000;
        }}
        
        .content {{
            background-color: #ffffff;
            padding: 10px;
        }}
        
        .sheet-tabs {{
            background-color: #c0c0c0;
            border-top: 1px solid #808080;
            padding: 4px 8px;
            font-size: 11px;
            display: flex;
            gap: 5px;
        }}
        
        .sheet-tab {{
            background: white;
            border: 1px solid #808080;
            border-bottom: none;
            padding: 2px 12px;
            cursor: pointer;
        }}
        
        .sheet-tab.active {{
            background: #ffffff;
            font-weight: bold;
            border-bottom: 2px solid white;
        }}
        
        table {{
            width: 100%;
            border-collapse: collapse;
            font-size: 11px;
            margin: 10px 0;
        }}
        
        th {{
            background: linear-gradient(180deg, #ffffff, #c0c0c0);
            border: 1px solid #808080;
            padding: 4px 8px;
            text-align: left;
            font-weight: bold;
            color: #000000;
        }}
        
        td {{
            border: 1px solid #c0c0c0;
            padding: 4px 8px;
            background: white;
        }}
        
        tr:hover td {{
            background: #e0e0ff;
        }}
        
        .row-header {{
            background: linear-gradient(90deg, #ffffff, #c0c0c0);
            border: 1px solid #808080;
            text-align: center;
            font-weight: bold;
            color: #000000;
            width: 30px;
        }}
        
        .section-header {{
            background: #000080 !important;
            color: white !important;
            font-weight: bold;
            font-size: 12px;
            padding: 6px 8px !important;
        }}
        
        .progress-cell {{
            font-family: 'Courier New', monospace;
            font-size: 10px;
            letter-spacing: 1px;
        }}
        
        .completed-row {{
            background: #90ee90 !important;
        }}
        
        .status-bar {{
            background-color: #c0c0c0;
            border-top: 1px solid #ffffff;
            padding: 2px 8px;
            font-size: 10px;
            display: flex;
            justify-content: space-between;
        }}
        
        .status-section {{
            padding: 0 8px;
            border-right: 1px solid #808080;
        }}
        
        .percentage {{
            font-weight: bold;
            color: #000080;
        }}
        
        .completed-badge {{
            background: #008000;
            color: white;
            padding: 1px 6px;
            border-radius: 2px;
            font-size: 9px;
            font-weight: bold;
        }}
    </style>
</head>
<body>
    <div class="window">
        <div class="title-bar">
            <div class="title-bar-text">
                <span class="title-bar-icon">📊</span>
                <span>Media Progress Tracker.xls</span>
            </div>
            <div class="title-bar-controls">
                <div class="title-button">_</div>
                <div class="title-button">□</div>
                <div class="title-button">✕</div>
            </div>
        </div>
        
        <div class="menu-bar">
            <span class="menu-item">File</span>
            <span class="menu-item">Edit</span>
            <span class="menu-item">View</span>
            <span class="menu-item">Insert</span>
            <span class="menu-item">Format</span>
            <span class="menu-item">Tools</span>
            <span class="menu-item">Data</span>
            <span class="menu-item">Window</span>
            <span class="menu-item">Help</span>
        </div>
        
        <div class="toolbar">
            <button class="toolbar-button">📄 New</button>
            <button class="toolbar-button">📁 Open</button>
            <button class="toolbar-button">💾 Save</button>
            <button class="toolbar-button">🖨️ Print</button>
            <button class="toolbar-button">✂️ Cut</button>
            <button class="toolbar-button">📋 Copy</button>
        </div>
        
        <div class="content">
"""
    
    # All Items Table
    all_items = []
    
    # Gather all items
    for movie in data.get("movies", []):
        all_items.append(("Movie", movie))
    for show in data.get("tv_shows", []):
        all_items.append(("TV Show", show))
    for book in data.get("books", []):
        all_items.append(("Book", book))
    
    # Sort: in-progress first, then completed
    in_progress = [(t, i) for t, i in all_items if not i.get("completed")]
    completed = [(t, i) for t, i in all_items if i.get("completed")]
    
    if in_progress or completed:
        html += """
            <table>
                <thead>
                    <tr>
                        <th class="row-header">#</th>
                        <th>Title</th>
                        <th>Type</th>
                        <th>Creator</th>
                        <th>Total</th>
                        <th>Current</th>
                        <th>Progress Bar</th>
                        <th>%</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
"""
        
        # In Progress items
        if in_progress:
            html += """
                    <tr>
                        <td colspan="9" class="section-header">IN PROGRESS</td>
                    </tr>
"""
            for idx, (media_type, item) in enumerate(in_progress, 1):
                progress_bar = create_progress_bar(item['progress'])
                
                if media_type == "Movie":
                    creator = item.get('director', 'Unknown')
                    year = f" ({item.get('year', 'N/A')})"
                    total_label = f"{item['total']} min"
                    current_label = f"{item['current']} min"
                elif media_type == "TV Show":
                    creator = "—"
                    year = ""
                    total_label = f"{item['total']} min"
                    current_label = f"{item['current']} min"
                else:  # Book
                    creator = item.get('author', 'Unknown')
                    year = ""
                    total_label = f"{item['total']} pages"
                    current_label = f"page {item['current']}"
                
                html += f"""
                    <tr>
                        <td class="row-header">{idx}</td>
                        <td>{item['title']}{year}</td>
                        <td>{media_type}</td>
                        <td>{creator}</td>
                        <td>{total_label}</td>
                        <td>{current_label}</td>
                        <td class="progress-cell">{progress_bar}</td>
                        <td class="percentage">{item['progress']}%</td>
                        <td>⏳ Watching</td>
                    </tr>
"""
        
        # Completed items
        if completed:
            html += """
                    <tr>
                        <td colspan="9" class="section-header">COMPLETED</td>
                    </tr>
"""
            for idx, (media_type, item) in enumerate(completed, len(in_progress) + 1):
                
                if media_type == "Movie":
                    creator = item.get('director', 'Unknown')
                    year = f" ({item.get('year', 'N/A')})"
                    total_label = f"{item['total']} min"
                elif media_type == "TV Show":
                    creator = "—"
                    year = ""
                    total_label = f"{item['total']} min"
                else:  # Book
                    creator = item.get('author', 'Unknown')
                    year = ""
                    total_label = f"{item['total']} pages"
                
                html += f"""
                    <tr class="completed-row">
                        <td class="row-header">{idx}</td>
                        <td>{item['title']}{year}</td>
                        <td>{media_type}</td>
                        <td>{creator}</td>
                        <td>{total_label}</td>
                        <td>{item['total']}</td>
                        <td class="progress-cell">{"■" * 20}</td>
                        <td class="percentage">100%</td>
                        <td><span class="completed-badge">✓ DONE</span></td>
                    </tr>
"""
        
        html += """
                </tbody>
            </table>
"""
    
    # Calculate stats
    total_items = len(all_items)
    completed_count = len(completed)
    in_progress_count = len(in_progress)
    
    html += f"""
        </div>
        
        <div class="sheet-tabs">
            <div class="sheet-tab active">All Media</div>
            <div class="sheet-tab">Movies</div>
            <div class="sheet-tab">TV Shows</div>
            <div class="sheet-tab">Books</div>
        </div>
        
        <div class="status-bar">
            <div class="status-section">Ready</div>
            <div class="status-section">Total Items: {total_items}</div>
            <div class="status-section">In Progress: {in_progress_count}</div>
            <div class="status-section">Completed: {completed_count}</div>
            <div class="status-section">Last Updated: {datetime.now().strftime('%m/%d/%Y %I:%M %p')}</div>
        </div>
    </div>
</body>
</html>
"""
    
    with open(output_file, 'w') as f:
        f.write(html)
    
    print(f"✓ Generated Excel-style: {output_file}")
