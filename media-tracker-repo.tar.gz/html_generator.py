"""
HTML Generator for Media Tracker
Creates a retro terminal-styled static HTML page
"""

from datetime import datetime
from typing import Dict


def create_progress_bar(progress: float, width: int = 20) -> str:
    """Create ASCII progress bar"""
    filled = int((progress / 100) * width)
    empty = width - filled
    return "█" * filled + "░" * empty


def generate_html_page(data: Dict, output_file: str):
    """Generate static HTML page with terminal styling"""
    
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Media Progress Tracker</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            background-color: #0a0e0f;
            color: #00ff41;
            font-family: 'Courier New', monospace;
            padding: 20px;
            line-height: 1.6;
            min-height: 100vh;
        }}
        
        .container {{
            max-width: 900px;
            margin: 0 auto;
            background-color: #0d1117;
            border: 2px solid #00ff41;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 0 20px rgba(0, 255, 65, 0.3);
        }}
        
        .header {{
            text-align: center;
            border: 1px solid #00ff41;
            padding: 20px;
            margin-bottom: 30px;
            background-color: #0a0e0f;
        }}
        
        .header h1 {{
            font-size: 24px;
            margin-bottom: 10px;
            letter-spacing: 2px;
        }}
        
        .header .prompt {{
            color: #00ff41;
            opacity: 0.7;
        }}
        
        .section {{
            margin-bottom: 30px;
        }}
        
        .section-title {{
            color: #00ff41;
            font-size: 18px;
            margin-bottom: 15px;
            padding-bottom: 5px;
            border-bottom: 1px solid #00ff41;
        }}
        
        .section-title::before {{
            content: "> ";
            color: #00ff41;
        }}
        
        .item {{
            margin-bottom: 20px;
            padding: 15px;
            background-color: #0a0e0f;
            border-left: 3px solid #00ff41;
        }}
        
        .item-title {{
            font-size: 16px;
            color: #00ff41;
            margin-bottom: 5px;
        }}
        
        .item-meta {{
            color: #00ff41;
            opacity: 0.7;
            font-size: 14px;
            margin-bottom: 8px;
        }}
        
        .progress-bar {{
            font-size: 14px;
            margin: 8px 0;
            letter-spacing: 1px;
        }}
        
        .progress-text {{
            color: #00ff41;
            margin-top: 5px;
            font-size: 13px;
        }}
        
        .completed {{
            border-left-color: #39d353;
        }}
        
        .completed .item-title::after {{
            content: " ✓";
            color: #39d353;
        }}
        
        .footer {{
            text-align: center;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #00ff41;
            color: #00ff41;
            opacity: 0.5;
            font-size: 12px;
        }}
        
        .scanline {{
            pointer-events: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: repeating-linear-gradient(
                0deg,
                rgba(0, 0, 0, 0.15),
                rgba(0, 0, 0, 0.15) 1px,
                transparent 1px,
                transparent 2px
            );
            z-index: 9999;
        }}
        
        @keyframes flicker {{
            0%, 100% {{ opacity: 1; }}
            50% {{ opacity: 0.95; }}
        }}
        
        .container {{
            animation: flicker 0.15s infinite;
        }}
    </style>
</head>
<body>
    <div class="scanline"></div>
    <div class="container">
        <div class="header">
            <pre>
╔════════════════════════════════════════════════╗
║       MEDIA PROGRESS TRACKER v1.0              ║
║       [user@tracker ~]$                        ║
╚════════════════════════════════════════════════╝
            </pre>
            <p class="prompt">Last updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
        </div>
"""
    
    # Movies section
    movies = [m for m in data.get("movies", []) if not m.get("completed")]
    completed_movies = [m for m in data.get("movies", []) if m.get("completed")]
    
    if movies:
        html += """
        <div class="section">
            <div class="section-title">CURRENTLY WATCHING</div>
"""
        for movie in movies:
            progress_bar = create_progress_bar(movie['progress'])
            html += f"""
            <div class="item">
                <div class="item-title">{movie['title']} ({movie.get('year', 'N/A')})</div>
                <div class="item-meta">{movie['total']}min total | {movie['current']}min watched | Dir: {movie.get('director', 'Unknown')}</div>
                <div class="progress-bar">[{progress_bar}] {movie['progress']}%</div>
            </div>
"""
        html += """
        </div>
"""
    
    # TV Shows section
    tv_shows = [s for s in data.get("tv_shows", []) if not s.get("completed")]
    completed_shows = [s for s in data.get("tv_shows", []) if s.get("completed")]
    
    if tv_shows:
        html += """
        <div class="section">
            <div class="section-title">WATCHING SERIES</div>
"""
        for show in tv_shows:
            progress_bar = create_progress_bar(show['progress'])
            html += f"""
            <div class="item">
                <div class="item-title">{show['title']}</div>
                <div class="item-meta">{show['total']}min total | {show['current']}min watched</div>
                <div class="progress-bar">[{progress_bar}] {show['progress']}%</div>
            </div>
"""
        html += """
        </div>
"""
    
    # Books section
    books = [b for b in data.get("books", []) if not b.get("completed")]
    completed_books = [b for b in data.get("books", []) if b.get("completed")]
    
    if books:
        html += """
        <div class="section">
            <div class="section-title">READING</div>
"""
        for book in books:
            progress_bar = create_progress_bar(book['progress'])
            html += f"""
            <div class="item">
                <div class="item-title">{book['title']}</div>
                <div class="item-meta">{book['total']} pages | Page {book['current']} | {book.get('author', 'Unknown Author')}</div>
                <div class="progress-bar">[{progress_bar}] {book['progress']}%</div>
            </div>
"""
        html += """
        </div>
"""
    
    # Completed section
    all_completed = completed_movies + completed_shows + completed_books
    if all_completed:
        html += """
        <div class="section">
            <div class="section-title">COMPLETED ✓</div>
"""
        for item in all_completed:
            html += f"""
            <div class="item completed">
                <div class="item-title">{item['title']}</div>
"""
            if item['medium'] == 'movie':
                html += f"""                <div class="item-meta">Movie | {item['total']}min | Dir: {item.get('director', 'Unknown')}</div>
"""
            elif item['medium'] == 'tv':
                html += f"""                <div class="item-meta">TV Show | {item['total']}min</div>
"""
            else:
                html += f"""                <div class="item-meta">Book | {item['total']} pages | {item.get('author', 'Unknown Author')}</div>
"""
            html += """
            </div>
"""
        html += """
        </div>
"""
    
    # Footer
    html += f"""
        <div class="footer">
            <p>Generated by Media Progress Tracker | {datetime.now().strftime('%Y')}</p>
        </div>
    </div>
</body>
</html>
"""
    
    with open(output_file, 'w') as f:
        f.write(html)
    
    print(f"✓ Generated: {output_file}")
