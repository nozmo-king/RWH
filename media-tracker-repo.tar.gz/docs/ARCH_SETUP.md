# 🏴‍☠️ ARCH LINUX SETUP GUIDE

btw i use arch (and so do you!)

---

## 📦 Prerequisites

```bash
# Install Python and pip if not already installed
sudo pacman -S python python-pip

# Optional: Install system packages for dependencies
sudo pacman -S python-requests  # if you prefer system packages
```

---

## 🚀 Installation (3 commands)

```bash
# 1. Extract the zip
unzip media-tracker.zip -d ~/media-tracker
cd ~/media-tracker

# 2. Run Arch-specific setup
./setup_arch.sh

# 3. Start tracking!
./media_tracker.py
```

---

## 🎯 Arch-Specific Notes

### Package Management

**Option 1: Use pip (recommended for this project)**
```bash
pip install --user rich requests
```
- Installs to `~/.local/lib/python3.x/site-packages/`
- No root needed
- Won't conflict with system packages

**Option 2: Use system packages**
```bash
sudo pacman -S python-requests
yay -S python-rich  # or paru -S python-rich
```
- Better integration with pacman
- `python-rich` is in AUR

### No `--break-system-packages` Flag Needed

The setup script doesn't use `--break-system-packages` because:
- Arch doesn't have the same restrictive pip policies as Debian/Ubuntu
- Using `--user` flag is the Arch way
- System packages integrate properly

### Adding to PATH

If `./media_tracker.py` doesn't work, add `~/.local/bin` to PATH:

```bash
# Add to ~/.bashrc or ~/.zshrc
export PATH="$HOME/.local/bin:$PATH"

# Reload shell
source ~/.bashrc  # or source ~/.zshrc
```

---

## 🔧 Python Virtual Environment (Optional)

If you prefer complete isolation:

```bash
cd ~/media-tracker

# Create venv
python -m venv venv

# Activate
source venv/bin/activate

# Install dependencies
pip install rich requests

# Run tracker
./media_tracker.py

# Deactivate when done
deactivate
```

---

## 🎨 Ruby for Neocities (Optional)

If you want CLI deployment to Neocities:

```bash
# Install Ruby
sudo pacman -S ruby

# Install neocities gem
gem install neocities --user-install

# Add to PATH (if not already)
export PATH="$HOME/.gem/ruby/3.0.0/bin:$PATH"  # adjust version

# Configure deploy.sh with your API key
nano deploy.sh
```

---

## 🚀 Systemd Service (Pro Arch Move)

Want to run as a service? Create `/etc/systemd/system/media-tracker-sync.service`:

```ini
[Unit]
Description=Media Tracker HTML Generator
After=network.target

[Service]
Type=oneshot
User=youruser
WorkingDirectory=/home/youruser/media-tracker
ExecStart=/usr/bin/python /home/youruser/media-tracker/media_tracker.py --generate
StandardOutput=journal

[Install]
WantedBy=multi-user.target
```

And a timer `/etc/systemd/system/media-tracker-sync.timer`:

```ini
[Unit]
Description=Generate Media Tracker HTML daily

[Timer]
OnCalendar=daily
Persistent=true

[Install]
WantedBy=timers.target
```

Enable:
```bash
sudo systemctl daemon-reload
sudo systemctl enable --now media-tracker-sync.timer
```

---

## 📁 Recommended Directory Structure

```bash
~/.config/media-tracker/    # Config files
~/media-tracker/            # Application
~/media-tracker/backups/    # Data backups
```

---

## 🔥 Arch Pro Tips

**1. Create an alias:**
```bash
# Add to ~/.bashrc or ~/.zshrc
alias tracker='cd ~/media-tracker && ./media_tracker.py'
alias tracker-backup='cp ~/media-tracker/media_data.json ~/media-tracker/backups/media_$(date +%Y%m%d).json'
```

**2. Backup automation with cron:**
```bash
# Edit crontab
crontab -e

# Add daily backup at 2 AM
0 2 * * * cp ~/media-tracker/media_data.json ~/media-tracker/backups/media_$(date +\%Y\%m\%d).json
```

**3. Use rsync for deployment:**
```bash
# Instead of Neocities gem, rsync to your server
rsync -avz ~/media-tracker/index.html user@yourserver:/var/www/tracker/
```

---

## 🐛 Troubleshooting

### "No module named 'rich'"

```bash
pip install --user rich
```

### "Permission denied"

```bash
chmod +x media_tracker.py setup_arch.sh deploy.sh
```

### Python version issues

```bash
# Check version
python --version  # Should be 3.9+

# Use specific version
python3.11 media_tracker.py
```

### Locale issues with Unicode

```bash
# Add to ~/.bashrc
export LANG=en_US.UTF-8
export LC_ALL=en_US.UTF-8

# Regenerate locales if needed
sudo locale-gen
```

---

## 🎯 Quick Commands Cheat Sheet

```bash
# Setup
./setup_arch.sh

# Run TUI
./media_tracker.py

# Quick backup
cp media_data.json media_data_backup.json

# View logs (if using systemd)
journalctl -u media-tracker-sync

# Check what's using Python packages
pacman -Qo /usr/lib/python3.*/site-packages/*
```

---

## 📦 AUR Packages (Optional)

If you want bleeding-edge versions:

```bash
# Using yay
yay -S python-rich-git

# Using paru  
paru -S python-rich-git
```

---

## 🏗️ Building from Scratch (The Arch Way)

Want to package this yourself?

```bash
# Create PKGBUILD
mkdir -p ~/builds/media-tracker
cd ~/builds/media-tracker

# Write PKGBUILD
cat > PKGBUILD << 'EOF'
pkgname=media-tracker
pkgver=1.0
pkgrel=1
pkgdesc="TUI media progress tracker with HTML generation"
arch=('any')
depends=('python' 'python-requests')
makedepends=('python-pip')
source=("media-tracker.tar.gz")
md5sums=('SKIP')

package() {
    cd "$srcdir"
    install -Dm755 media_tracker.py "$pkgdir/usr/bin/media-tracker"
    # ... rest of package files
}
EOF

# Build
makepkg -si
```

---

## 🔐 Security Notes

**The API key in the script is a READ-ONLY TMDb token.**
- It can only fetch movie data
- Can't modify your TMDb account
- Safe to use as-is
- But you can get your own at https://www.themoviedb.org/settings/api

---

## 🌟 Arch Philosophy Applied

This project follows Arch principles:
- ✅ **Simplicity** - Plain text JSON storage, no bloat
- ✅ **User-centricity** - You control everything
- ✅ **Versatility** - Works on any Python system
- ✅ **Minimalism** - Small dependencies
- ✅ **Code correctness** - Python best practices

---

## 📚 Further Reading

- Arch Python Guidelines: https://wiki.archlinux.org/title/Python
- pip User Install: https://wiki.archlinux.org/title/Python#Package_management
- Systemd Services: https://wiki.archlinux.org/title/Systemd

---

**Keep it simple. Keep it Arch.** 🏴‍☠️

btw this guide was written on Arch
