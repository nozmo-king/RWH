# 🎨 STYLE GUIDE - Terminal vs Excel

Your tracker now supports **TWO STYLES** you can choose from when generating HTML!

---

## 🟢 STYLE 1: Terminal (Green CRT)

**Perfect for:** Retro hackers, Matrix fans, cyberpunk aesthetic

**What it looks like:**
- Black background (#0a0e0f)
- Green phosphor text (#00ff41)
- ASCII progress bars: [████████████░░░░░░░░]
- Scanline effects (like old CRT monitors)
- Screen flicker animation
- Monospace Courier font
- Minimal borders

**Preview:** Open `demo.html` in your browser

**Vibe:** 
```
╔════════════════════════════════════════════════╗
║       MEDIA PROGRESS TRACKER v1.0              ║
║       [user@tracker ~]$                        ║
╚════════════════════════════════════════════════╝

> CURRENTLY WATCHING

[████████████░░░░░░░░] 59.6% Gummo (1997)
89min total | 53min watched | Dir: Harmony Korine
```

**Best for:**
- Tech/hacker aesthetic
- Personal projects
- Developer portfolios
- Retro gaming sites

---

## 📊 STYLE 2: Excel 95/97

**Perfect for:** Nostalgia lovers, spreadsheet fans, Windows 95 aesthetic

**What it looks like:**
- Gray background (#c0c0c0)
- Windows 95 blue title bar (#000080)
- Classic Excel grid with borders
- Gradient column headers
- Progress bars: ■■■■■■■■■■□□□□□□□□□□
- Arial font (MS Sans Serif)
- Toolbar with buttons
- Sheet tabs at bottom
- Status bar

**Preview:** Open `demo_excel.html` in your browser

**Vibe:**
```
┌─────────────────────────────────────────────┐
│ 📊 Media Progress Tracker.xls        _ □ ✕ │
├─────────────────────────────────────────────┤
│ File Edit View Insert Format Tools Data... │
├─────────────────────────────────────────────┤
│ [📄] [📁] [💾] [🖨️] [✂️] [📋]              │
├─────────────────────────────────────────────┤
│                                             │
│  #  │ Title      │ Progress Bar  │ %      │
│ ────┼────────────┼──────────────┼───────  │
│  1  │ Gummo      │ ■■■■■■□□□□□□ │ 59.6% │
│                                             │
├─────────────────────────────────────────────┤
│ [All Media] [Movies] [TV Shows] [Books]    │
├─────────────────────────────────────────────┤
│ Ready │ Total: 5 │ Progress: 3 │ Done: 2  │
└─────────────────────────────────────────────┘
```

**Best for:**
- Nostalgia sites
- Retro computing blogs
- Y2K aesthetic
- Professional look with personality
- Meme sites (old Windows aesthetic is trendy)

---

## 🎯 How to Choose in the TUI

When you generate HTML (option 6):

```
Generate HTML

Choose Style:

1. Terminal (Green CRT / Matrix style)
2. Excel (Classic spreadsheet style)

Select style: _
```

Just type `1` or `2` and press Enter!

---

## 🎨 Feature Comparison

| Feature | Terminal | Excel |
|---------|----------|-------|
| Background | Black | Gray (Win95) |
| Text color | Green (#00ff41) | Black |
| Progress bars | Unicode blocks (█░) | Filled squares (■□) |
| Layout | Sections with headers | Spreadsheet grid |
| Font | Courier (monospace) | Arial |
| Effects | Scanlines + flicker | 3D borders |
| Table style | Minimal borders | Full grid |
| Header | ASCII art box | Windows title bar |
| Extra UI | None | Menu bar + toolbar + tabs |
| Nostalgia level | 1980s Unix | 1990s Windows |

---

## 🔧 Customizing Colors

### Terminal Style
Edit `html_generator.py` around line 26:

```python
background-color: #0a0e0f;  # Change to #000000 for pure black
color: #00ff41;             # Change to:
                            # #ffb000 for amber
                            # #00aaff for blue
                            # #ffffff for white
```

### Excel Style  
Edit `html_generator_excel.py` around line 20:

```python
background-color: #c0c0c0;  # Keep gray for authentic look
                            # Or try #e0e0e0 for lighter
```

---

## 💡 Pro Tips

**Mix and match:**
- Use Terminal style for your main site
- Use Excel style for sharing with non-techie friends (looks more "normal")

**Switch anytime:**
- Generate HTML in both styles
- Name them: `index.html` (terminal) and `spreadsheet.html` (excel)
- Link between them: "View Terminal Style | View Excel Style"

**Customize further:**
- Both generators are Python files
- Easy to edit colors, fonts, layouts
- Add your own styles!

---

## 📸 Quick Visual Guide

**Terminal Style = This:**
```
████████████░░░░░░░░ 60% ← Progress bar
Dark background
Green text
Hacker vibes
```

**Excel Style = This:**
```
■■■■■■■■■■■■□□□□□□□□ 60% ← Progress bar
Gray background  
Black text
Spreadsheet grid
Office vibes
```

---

## 🚀 Which Should You Use?

**Use Terminal if:**
- You want a cool/edgy aesthetic
- Your site has a tech/developer theme
- You like minimalist design
- You're going for cyberpunk vibes

**Use Excel if:**
- You want something familiar and nostalgic
- Your audience isn't super technical
- You love the Windows 95 aesthetic
- You want a "professional" spreadsheet look

**Use both if:**
- You can't decide (totally valid!)
- Different audiences
- Just because you can 😎

---

## 📦 What's Included

In your zip file:
- `html_generator.py` - Terminal style generator
- `html_generator_excel.py` - Excel style generator  
- `demo.html` - Terminal preview
- `demo_excel.html` - Excel preview
- `media_tracker.py` - TUI (asks which style you want)

---

**Bottom line:** Try both demos in your browser and pick the one you like! You can switch anytime. 🎨

**Happy styling!** 🎬📺📚
