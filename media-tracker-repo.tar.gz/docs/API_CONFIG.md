# API Configuration Guide

This guide explains how the APIs work and how to configure your own keys.

## APIs Used

### TMDb (The Movie Database)

**Used for**: Movies and TV shows  
**Requires**: API Key (free)  
**Documentation**: https://developers.themoviedb.org/3

#### Default Configuration

The project includes a working read-only TMDb API key. This key:
- ✅ Can fetch movie/TV data
- ✅ Safe to use in public code
- ✅ No account needed
- ❌ Cannot modify your TMDb account
- ❌ Rate limited to public API limits

#### Using Your Own Key

1. **Sign up** at https://www.themoviedb.org
2. **Get API key**: Go to Settings → API → Request API Key
3. **Choose v4 Bearer Token** (recommended) or v3 API Key
4. **Replace in code**: Edit `media_tracker.py` line 28

```python
# Replace this line:
TMDB_TOKEN = "eyJhbGciOiJIUzI1NiJ9..."

# With your token:
TMDB_TOKEN = "YOUR_TOKEN_HERE"
```

#### Environment Variable (Recommended)

Better security - use environment variables:

```bash
# Add to ~/.bashrc or ~/.zshrc
export TMDB_API_TOKEN="your_token_here"
```

Then modify `media_tracker.py`:
```python
import os
TMDB_TOKEN = os.getenv('TMDB_API_TOKEN', 'default_token_here')
```

---

### Google Books API

**Used for**: Books  
**Requires**: No API key needed!  
**Documentation**: https://developers.google.com/books

#### Default Configuration

Google Books API works without authentication for basic searches.

**Limits**:
- 1000 requests per day (anonymous)
- 100 requests per 100 seconds

#### Optional: API Key for Higher Limits

If you need more requests:

1. **Go to**: https://console.cloud.google.com
2. **Create project** or select existing
3. **Enable** Google Books API
4. **Create credentials** → API Key
5. **Add to code**: Edit `media_tracker.py`

```python
# In search_book function, add to params:
params = {
    "q": title,
    "key": "YOUR_GOOGLE_API_KEY"  # Add this line
}
```

---

## API Rate Limits

### TMDb
- **Public**: 40 requests per 10 seconds
- **Authenticated**: 40 requests per 10 seconds
- **Per day**: Unlimited

### Google Books
- **Anonymous**: 1000 requests per day
- **With API key**: Up to 10,000 requests per day

### Handling Rate Limits

The app currently doesn't implement rate limiting. If you hit limits:

**Option 1: Add delays**
```python
import time
time.sleep(0.5)  # Wait 500ms between requests
```

**Option 2: Use caching** (future enhancement)

---

## API Response Examples

### TMDb Movie Search Response

```json
{
  "results": [
    {
      "id": 27205,
      "title": "Inception",
      "release_date": "2010-07-16",
      "runtime": 148
    }
  ]
}
```

### TMDb Movie Details Response

```json
{
  "id": 27205,
  "title": "Inception",
  "runtime": 148,
  "release_date": "2010-07-16"
}
```

### Google Books Response

```json
{
  "items": [
    {
      "volumeInfo": {
        "title": "Neuromancer",
        "authors": ["William Gibson"],
        "pageCount": 271
      }
    }
  ]
}
```

---

## Troubleshooting

### "Invalid API key"

**TMDb**: 
- Check your token is correct
- Ensure it's a v4 Bearer token, not v3 API key
- Check it's not expired

**Google Books**:
- Verify API is enabled in Cloud Console
- Check API key restrictions

### "Rate limit exceeded"

- Wait a few minutes
- Add delays between requests
- Get your own API key for higher limits

### "No results found"

- Check spelling of title
- Try shorter/simpler search terms
- Try searching year: "inception 2010"

---

## Security Best Practices

### DO ✅

- Use environment variables for API keys
- Add `.env` to `.gitignore`
- Rotate keys periodically
- Use read-only keys when possible

### DON'T ❌

- Commit API keys to Git
- Share personal API keys publicly
- Use production keys for development
- Hardcode sensitive keys

---

## Alternative APIs (Future)

### Potential Integrations

**Movies/TV:**
- OMDb API (requires key)
- Trakt.tv API (OAuth, auto-tracking)
- TVDB API (TV shows)

**Books:**
- Open Library API (free, no key)
- Goodreads API (deprecated, read-only)

**Anime/Manga:**
- Anilist API (free, GraphQL)
- MyAnimeList API (requires key)

Want to add these? See [CONTRIBUTING.md](../CONTRIBUTING.md)!

---

## API Status

Check if APIs are working:

**TMDb**: https://status.themoviedb.org/  
**Google**: https://status.cloud.google.com/

---

## Questions?

Open an issue: https://github.com/YOUR-USERNAME/media-tracker/issues
