# Git Repository Setup Guide

This file guides you through setting up your Git repository for the first time.

## Initial Commit Checklist

### Before You Commit

- [ ] **Update README.md**
  - Replace `YOUR-USERNAME` with your GitHub username
  - Add actual screenshots to `screenshots/`
  - Update badges if needed

- [ ] **Review API Key**
  - The TMDb token in `media_tracker.py` is a read-only demo key
  - It's safe to commit, but you can replace it with your own
  - See `docs/API_CONFIG.md` for details

- [ ] **Check .gitignore**
  - Ensure `media_data.json` is ignored (already done)
  - Add any personal config files you create

- [ ] **Test the Setup**
  ```bash
  ./setup.sh  # or ./setup_arch.sh
  ./media_tracker.py
  ```

### Initialize Git

```bash
# Initialize repository
git init

# Add all files
git add .

# Check what will be committed
git status

# Make initial commit
git commit -m "Initial commit: Media Progress Tracker v1.0"
```

### Create GitHub Repository

1. Go to https://github.com/new
2. Name: `media-tracker` (or your preference)
3. Description: "Track movies, TV shows, and books with automatic API integration"
4. Public or Private (your choice)
5. **Don't** initialize with README (you already have one)
6. Create repository

### Push to GitHub

```bash
# Add remote (replace YOUR-USERNAME)
git remote add origin https://github.com/YOUR-USERNAME/media-tracker.git

# Push to main branch
git branch -M main
git push -u origin main
```

### After First Push

- [ ] **Enable GitHub Pages** (if you want to host docs)
  - Settings → Pages → Source: Deploy from branch (main, /docs)

- [ ] **Add Topics**
  - Click gear icon next to "About"
  - Add: `python`, `tui`, `media-tracker`, `tmdb`, `terminal`, `static-site`

- [ ] **Update Repository Settings**
  - Add description
  - Add website URL (if you deploy somewhere)
  - Enable Issues

- [ ] **Create First Release**
  - Go to Releases → Create new release
  - Tag: `v1.0.0`
  - Title: "v1.0.0 - Initial Release"
  - Describe features

## Optional: GitHub Actions

Want automated testing? Create `.github/workflows/test.yml`:

```yaml
name: Test

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ["3.9", "3.10", "3.11", "3.12"]
    
    steps:
    - uses: actions/checkout@v3
    - name: Set up Python
      uses: actions/setup-python@v4
      with:
        python-version: ${{ matrix.python-version }}
    - name: Install dependencies
      run: |
        pip install -r requirements.txt
    - name: Run tracker
      run: |
        python media_tracker.py --help || true
```

## Branching Strategy

Recommended branches:
- `main` - Stable releases
- `develop` - Active development
- `feature/*` - New features
- `fix/*` - Bug fixes

## Version Tagging

Follow semantic versioning: `vMAJOR.MINOR.PATCH`

```bash
# Create version tag
git tag -a v1.0.0 -m "Initial release"
git push origin v1.0.0
```

## Maintenance

Regular tasks:
- Update dependencies in `requirements.txt`
- Review and merge PRs
- Respond to issues
- Update documentation
- Create releases for major changes

## Security

**Important**:
- Never commit real API keys (the demo key is fine)
- Review PRs for malicious code
- Keep dependencies updated
- Use Dependabot for security alerts

## Community

Consider adding:
- Code of Conduct
- Security policy
- Funding/sponsors info
- Wiki for extended docs

## Questions?

See CONTRIBUTING.md for contribution guidelines.

---

**Ready to commit?** Follow the checklist and push to GitHub! 🚀
